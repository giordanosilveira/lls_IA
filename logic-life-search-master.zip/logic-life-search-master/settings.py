verbosity = 2  # 0, 1, 2 or 3
pattern_output_format = "rle"  # "rle" or "csv"
life_encoding_method = 1  # 0, 1 or 2
rulestring = "B3/S23"  # Any valid rulestring
solver = "kissat"  # Any solver in /solvers
background = "possible_strobing"  # Any file in /backgrounds
